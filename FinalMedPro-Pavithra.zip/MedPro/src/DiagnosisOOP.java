/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.ArrayList;
import java.util.Collections;
/**
 *
 * @author ratam
 */
public class DiagnosisOOP { //modular code to reduce the repetition for the duagnsosis mechanism
    //decalring the variables
    String diseases;
    String disc;
    String med;
    String doctor;
    String possibility1;
    String possibility2;
    String possibility3;
    ArrayList<String> list;
    ArrayList<String> symptoms;
    
    //constructors
    
    public DiagnosisOOP (){
        diseases = "";
        disc = "";
        med = "";
        doctor = "";
        possibility1 = "";
        possibility2 = "";
        possibility3 = "";
        list = new ArrayList<String>();
        symptoms  = new ArrayList<String>();
      }
      
      
    DiagnosisOOP (String d, String i, String m, String o, String p1, String p2, String p3, ArrayList<String> l, ArrayList<String> s){
        diseases = d;
        disc = i;
        med = m;
        doctor = o;
        possibility1 = p1;
        possibility2 = p2;
        possibility3 = p3;
        list = l;
        symptoms  = s;
    }
    
    //getter
    public String getDiseases(){
        return diseases;
    }
    
    public String getDisc(){
        return disc;
    }
    
    public String getMed(){
        return med;
    }
    
    public String getDoctor(){
        return doctor;
    }
    
    public String getPossibility1(){
        return possibility1;
    }
    
    public String getPossibility2(){
        return possibility2;
    }
    
    public String getPossibility3(){
        return possibility3;
    }
    
    //outputs the diagnosis page with the correct information using variables from the Manual2 page
    public void results(){
                int probability = 0;//makes sure the illness has at least 3 of the symptoms the user described

                    for (String item: symptoms){//does the following for every symptom the user entered 
                        for (int i=0; i<5; i++){ //repeates the follwoing 5 times
                            if (item.equals(list.get(0))){ // compared entered symptom with the first item in the list of symptoms for an illness, only proceeds if a match was found
                                probability+=1; //adds 1 to probability for each match
                                
                                System.out.println(probability); //for debugging
                                if (probability >=3){ //the diagnosis occurs when therea re at least three matches

                                    /*Diagnosis d = new Diagnosis(); //creates new instance of Diagnosis class
                                    d.jLabel10.setText(diseases); //sets all the textfields for the instance
                                    d.Pane.setText(disc);
                                    d.jLabel7.setText(med);
                                    d.jLabel6.setText(doctor);
                                    d.jLabel12.setText(possibility1);
                                    d.jLabel13.setText(possibility2);
                                    d.jLabel14.setText(possibility3); 
                                    System.out.println("Done"); //for debugging
                                    d.show(); //diplays the now ready diagnosis page*/
                                    break;
                                }
                            }
                            System.out.println(list); //for debugging
                            Collections.rotate(list, -1); //moves the first item in the list to the last place so that with each run, the entered symptom is compared with a new illness symptom

                        }
                    } 
                    
                    if (probability < 3){ //if there's no diagnosis registered, it will let the user know
                        Manual2 m2 = new Manual2();
                        m2.show();
                        //Unidentified u = new Unidentified(); //initiates the instance of this class to let the user know their illness is not yet registered with us
                        //u.jEditorPane1.setText("This illness is not registered with us yet. Our team is working hard to bring you fast and accurate diagnoses with each update. Stay tuned! For now, try our advanced search option for a diagnosis, or enter a different combination of symptoms "); //updates and writes to the panel in the instance
                        //u.show(); //diplays the instance
                    }
    }
    

}
